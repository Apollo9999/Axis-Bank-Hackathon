#!/bin/bash
./gradlew :speech:clean :speech:bintrayUpload
