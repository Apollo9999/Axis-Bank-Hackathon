package net.gotev.speech.ui.animators;

public interface BarParamsAnimator {
    void start();
    void stop();
    void animate();
}
